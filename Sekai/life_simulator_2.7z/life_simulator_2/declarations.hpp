#ifndef DECLARATIONS_HPP 
#define DECLARATIONS_HPP  

class Company;
class Project;
class Worker;

#endif

